console.log("page loading");


function add1(){
    document.getElementById('count1').innerHTML++;
}
function add2(){
    document.getElementById('count2').innerHTML++;
}
function add3(){
    document.getElementById('count3').innerHTML++;
}